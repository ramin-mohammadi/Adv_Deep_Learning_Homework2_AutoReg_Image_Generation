from . import tests  # noqa


from .grader import run

print("Val grader loaded.")

run()
